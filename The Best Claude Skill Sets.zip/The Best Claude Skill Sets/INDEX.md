# The Best Claude Skill Sets

A curated collection of the two most credible, actively-maintained Claude Skills
repositories on GitHub, packaged so you can drop them straight into
`~/.claude/skills/` (personal) or `.claude/skills/` (per-project).

## What's inside

### 1. Official Anthropic Skills
Source: https://github.com/anthropics/skills (Anthropic's own repo — the same
SKILL.md format Claude Code and claude.ai load natively).

Includes: docx, pdf, pptx, xlsx (document creation/editing), frontend-design,
canvas-design, algorithmic-art, brand-guidelines, theme-factory,
web-artifacts-builder, webapp-testing, mcp-builder, skill-creator,
doc-coauthoring, internal-comms, claude-api, slack-gif-creator.

### 2. Superpowers Skills
Source: https://github.com/obra/superpowers-skills (community-maintained,
20+ battle-tested skills, widely cited as one of the best third-party skill
libraries). Companion plugin: https://github.com/obra/superpowers-marketplace
(install via `/plugin marketplace add obra/superpowers-marketplace`).

Includes: architecture, collaboration, debugging (systematic-debugging),
meta, problem-solving, research, testing (TDD), using-skills.

## How to install a skill
1. Pick a skill folder (it must contain a `SKILL.md` file).
2. Copy it into `~/.claude/skills/<skill-name>/` for personal use, or
   `.claude/skills/<skill-name>/` inside a project repo.
3. Restart Claude Code or run `/reload-skills`. Claude will auto-load the
   skill's name/description (~100 tokens) and pull in the full instructions
   only when relevant.

## A note on trust and safety
Skills can bundle scripts that execute code in your environment. Only
install skills from sources you trust. The two repos above are either
Anthropic's own or one of the most widely used community collections, but
you should still skim each SKILL.md before use — especially any skill that
shells out, hits external APIs, or touches credentials.

## Further browsing (not bundled — just link lists, nothing to download)
- https://github.com/ComposioHQ/awesome-claude-skills — large curated
  directory across 50+ categories
- https://awesomeclaude.ai/awesome-claude-skills — searchable directory,
  169+ community skills
- https://github.com/hesreallyhim/awesome-claude-code — broader Claude Code
  resource list (skills, agents, plugins, tooling)

These are meta-lists of links to individual GitHub repos, not skill
packages themselves, so they aren't included in this zip — but they're
good places to keep discovering new skills over time.
